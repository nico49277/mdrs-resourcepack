#!/usr/bin/env python3
"""
MDRS Spezialschaufeln - Textur-Generator
Erstellt einfache 16x16 Platzhalter-Texturen fuer die drei Schaufeln.

Ausfuehren:
    python generate_textures.py

Die Texturen werden in assets/minecraft/textures/item/ gespeichert.
Du kannst sie danach durch eigene Texturen ersetzen.
"""

import struct
import zlib
import os

def create_shovel_png(filepath, r, g, b):
    """Erstellt ein 16x16 PNG mit einer einfachen Schaufel-Silhouette."""
    width, height = 16, 16

    # Pixel-Daten aufbauen
    raw = bytearray()
    for y in range(height):
        raw.append(0)  # Filter: None
        for x in range(width):
            # Schaufel-Form:
            # Blatt (breit, oben):    x 3-12, y 1-5
            # Schaft (schmal, unten): x 6-9,  y 4-15
            is_blade  = (3 <= x <= 12) and (1 <= y <= 5)
            is_handle = (6 <= x <= 9) and (4 <= y <= 15)

            if is_blade:
                raw.extend([r, g, b, 255])
            elif is_handle:
                # Dunklerer Schaft
                raw.extend([r // 2, g // 2, b // 2, 255])
            else:
                raw.extend([0, 0, 0, 0])  # Transparent

    # PNG bauen
    def make_chunk(chunk_type, data):
        chunk = chunk_type + data
        crc = zlib.crc32(chunk) & 0xFFFFFFFF
        return struct.pack('>I', len(data)) + chunk + struct.pack('>I', crc)

    signature = b'\x89PNG\r\n\x1a\n'
    ihdr_data = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    idat_data = zlib.compress(bytes(raw), 9)

    png = signature
    png += make_chunk(b'IHDR', ihdr_data)
    png += make_chunk(b'IDAT', idat_data)
    png += make_chunk(b'IEND', b'')

    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'wb') as f:
        f.write(png)
    print(f"  Erstellt: {filepath} ({len(png)} Bytes)")

print("MDRS Spezialschaufeln - Textur-Generator")
print("=" * 40)

base = os.path.join(os.path.dirname(__file__), 'assets', 'minecraft', 'textures', 'item')

# V1: Hellblau (Diamant)
create_shovel_png(os.path.join(base, 'mdrs_schaufel_v1.png'), 100, 180, 255)
# V2: Gruen (verbessert)
create_shovel_png(os.path.join(base, 'mdrs_schaufel_v2.png'), 80, 220, 120)
# V3: Gold/Orange (Netherit, ultimativ)
create_shovel_png(os.path.join(base, 'mdrs_schaufel_v3.png'), 255, 170, 50)

print("=" * 40)
print("Fertig! Du kannst die PNGs durch eigene Texturen ersetzen.")
print("Wichtig: Behalte die Dateinamen bei!")

# MDRS Spezialschaufeln - Resource Pack

## Textur-Generierung

### Schnellstart (Windows)
1. Doppelklicke auf `generate_textures.bat`
   (oder fuehre `python generate_textures.py` aus)
2. Die Platzhalter-Texturen werden automatisch erstellt.

### Eigene Texturen
Du kannst die generierten PNGs durch eigene 16x16 Texturen ersetzen.
Wichtig: Behalte die Dateinamen bei!
- `mdrs_schaufel_v1.png` - Schaufel V1
- `mdrs_schaufel_v2.png` - Schaufel V2
- `mdrs_schaufel_v3.png` - Schaufel V3

## Resource Pack packen

1. Markiere alle Dateien **innerhalb** des `resource_pack` Ordners
   (also `pack.mcmeta` und den `assets` Ordner)
2. Komprimiere sie zu einem `.zip` Archiv
3. Benenne die ZIP-Datei z.B. `MDRS-Spezialschaufeln-Texturen.zip`

## Resource Pack installieren

### Variante A: Server-seitig (Paper)
1. Kopiere die ZIP-Datei in den `resource_packs/` Ordner deines Servers
2. Konfiguriere die `server.properties`:
   ```
   require-resource-pack=true
   resource-pack=https://dein-download-link.zip
   resource-pack-sha1=<sha1-hash>
   ```
   Oder nutze ein Plugin wie `ForceResourcePack`

### Variante B: Manuelles Resource Pack
1. Kopiere die ZIP-Datei in deinen Minecraft `resourcepacks` Ordner
   (`.minecraft/resourcepacks/`)
2. Aktiviere es in Minecraft unter Options > Resource Packs

## Custom Model Data
Das Plugin setzt folgende Custom Model Data Werte:
- Schaufel V1: `1`
- Schaufel V2: `2`
- Schaufel V3: `3`

Das Resource Pack enthaelt sowohl das neue (1.21.4+) als auch das alte
(Pre-1.21.4) Item-Model-Format, fuer maximale Kompatibilitaet.

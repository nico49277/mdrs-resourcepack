@echo off
echo MDRS Spezialschaufeln - Textur-Generator
echo =========================================
python generate_textures.py
if errorlevel 1 (
    echo.
    echo FEHLER: Python wurde nicht gefunden!
    echo Bitte installiere Python von https://python.org
    echo und fuehre diese Datei erneut aus.
)
pause
